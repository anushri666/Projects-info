# Shape Geometry Calculator

## Overview

This program demonstrates Object-Oriented Programming in C++ by modeling geometric shapes and calculating their properties.

## Compilation

To compile the program, use:

```bash
g++ -o shapes main.cpp Circle.cpp Shape.cpp -lm
```

## Run

```bash
./shapes
```
