#include "Rectangle.h"

Rectangle::Rectangle(const string& color, int id, double length, double width)
    : Shape(color, id), length(length), width(width) {}

double Rectangle::area() const {
    return length * width;
}

double Rectangle::perimeter() const {
    return 2 * (length + width);
}

string Rectangle::getType() const {
    return "Rectangle";
}

void Rectangle::display() const {
    cout << "Shape ID: " << id << ", Type: " << getType()
         << ", Color: " << color << ", Length: " << length
         << ", Width: " << width << ", Area: " << area()
         << ", Perimeter: " << perimeter() << endl;
}

double Rectangle::getLength() const { return length; }
double Rectangle::getWidth() const { return width; }

void Rectangle::setLength(double l) { length = l; }
void Rectangle::setWidth(double w) { width = w; }

Rectangle& Rectangle::operator*=(double factor) {
    length *= factor;
    width *= factor;
    return *this;
}

bool Rectangle::operator==(const Rectangle& other) const {
    return length == other.length && width == other.width;
}

ostream& operator<<(ostream& os, const Rectangle& rect) {
    os << "Rectangle(ID=" << rect.id << ", L=" << rect.length << ", W=" << rect.width << ")";
    return os;
}
