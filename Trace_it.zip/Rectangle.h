#ifndef RECTANGLE_H
#define RECTANGLE_H

#include "Shape.h"
#include <iostream>

class Rectangle : public Shape {
private:
    double length;
    double width;

public:
    Rectangle(const string& color, int id, double length, double width);
    ~Rectangle() override {}

    double area() const override;
    double perimeter() const override;
    string getType() const override;
    void display() const override;

    double getLength() const;
    double getWidth() const;
    void setLength(double length);
    void setWidth(double width);

    Rectangle& operator*=(double factor);
    bool operator==(const Rectangle& other) const;
    friend ostream& operator<<(ostream& os, const Rectangle& rect);
};

#endif
