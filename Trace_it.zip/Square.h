#ifndef SQUARE_H
#define SQUARE_H

#include "Shape.h"
#include <iostream>

class Square : public Shape {
private:
    double side;

public:
    Square(const string& color, int id, double side);
    ~Square() override {}

    double area() const override;
    double perimeter() const override;
    string getType() const override;
    void display() const override;

    double getSide() const;
    void setSide(double side);

    Square& operator-=(double amount);
    bool operator==(const Square& other) const;
    friend ostream& operator<<(ostream& os, const Square& square);
};

#endif
