#include "Square.h"

Square::Square(const string& color, int id, double side)
    : Shape(color, id), side(side) {}

double Square::area() const {
    return side * side;
}

double Square::perimeter() const {
    return 4 * side;
}

string Square::getType() const {
    return "Square";
}

void Square::display() const {
    cout << "Shape ID: " << id << ", Type: " << getType()
         << ", Color: " << color << ", Side: " << side
         << ", Area: " << area() << ", Perimeter: " << perimeter() << endl;
}

double Square::getSide() const { return side; }
void Square::setSide(double s) { side = s; }

Square& Square::operator-=(double amount) {
    side -= amount;
    return *this;
}

bool Square::operator==(const Square& other) const {
    return side == other.side;
}

ostream& operator<<(ostream& os, const Square& square) {
    os << "Square(ID=" << square.id << ", Side=" << square.side << ")";
    return os;
}
