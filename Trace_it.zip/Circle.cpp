#include "Circle.h"
#include <cmath>

Circle::Circle(const string& color, int id, double radius)
    : Shape(color, id), radius(radius) {}

double Circle::area() const {
    return M_PI * radius * radius;
}

double Circle::perimeter() const {
    return 2 * M_PI * radius;
}

string Circle::getType() const {
    return "Circle";
}

void Circle::display() const {
    cout << "Shape ID: " << id << ", Type: " << getType()
         << ", Color: " << color << ", Radius: " << radius
         << ", Area: " << area() << ", Perimeter: " << perimeter() << endl;
}

double Circle::getRadius() const {
    return radius;
}

void Circle::setRadius(double r) {
    radius = r;
}

double Circle::getDiameter() const {
    return 2 * radius;
}

Circle& Circle::operator+=(double scalar) {
    radius += scalar;
    return *this;
}

bool Circle::operator==(const Circle& other) const {
    return radius == other.radius;
}

ostream& operator<<(ostream& os, const Circle& circle) {
    os << "Circle(ID=" << circle.id << ", Radius=" << circle.radius << ")";
    return os;
}
