#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "Shape.h"
#include <iostream>

class Triangle : public Shape {
private:
    double a, b, c; // side lengths

public:
    Triangle(const string& color, int id, double a, double b, double c);
    ~Triangle() override {}

    double area() const override;
    double perimeter() const override;
    string getType() const override;
    void display() const override;

    Triangle& operator+=(double d);
    bool operator==(const Triangle& other) const;
    friend ostream& operator<<(ostream& os, const Triangle& t);
};

#endif
