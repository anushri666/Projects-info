# Traceit — Physically-Based Ray Tracer

A physically-based ray tracer built from scratch in C++ using OOP, with **zero external
libraries** — no graphics API, no math library, no image library. Everything (vectors,
scene intersection, BVH, PPM image writer) is hand-rolled.

![Cornell Box Render](cornell_box_render.png)

## Features

| Feature | Where it lives |
|---|---|
| Reflections & realistic shadows | `material.h` (`metal`), `main.cpp` (`ray_color`, 0.001 shadow-acne epsilon) |
| Refraction via **Snell's Law** + Schlick Fresnel | `vec3.h` (`refract`), `material.h` (`dielectric`) |
| **Lambertian** diffuse model | `material.h` (`lambertian`) |
| **Perlin noise** procedural textures | `perlin.h`, `texture.h` (`noise_texture`) |
| **Motion blur** (time-sampled rays) | `camera.h`, `sphere.h` (`moving_sphere`) |
| **Volumetric lighting** (participating media / fog) | `constant_medium.h` |
| Matte / metal / glass materials | `material.h` |
| **BVH acceleration structure** | `bvh.h` |
| Cornell Box scene | `main.cpp` (`cornell_box()`) |

## Build & Run

```bash
make            # builds ./traceit
make run        # builds, renders at 400x400 @ 100spp, converts to PNG
```

Or manually:

```bash
g++ -O3 -std=c++17 src/main.cpp -o traceit
./traceit <image_width> <samples_per_pixel>

# e.g. to match the "500 spp" figure from the writeup:
./traceit 600 500
```

This writes `render.ppm` (plain PPM/P3). Convert to PNG with ImageMagick:

```bash
convert render.ppm render.png
```

Render time and image dimensions/sample-count are printed to stderr, e.g.:

```
Rendering 600x600 @ 500 spp, max_depth=50
Done in 14.9s
```

## How each resume line maps to code

- **"Built a physically-based ray tracer from scratch in C++ using OOP"** — `hittable`
  is an abstract base class; `sphere`, `xy_rect`/`xz_rect`/`yz_rect`, `box`, `bvh_node`,
  `translate`, `rotate_y`, `constant_medium` all derive from it and implement
  `hit()`/`bounding_box()`. `material` is likewise polymorphic (`lambertian`, `metal`,
  `dielectric`, `diffuse_light`, `isotropic`).
- **"Simulating reflections, refractions, and realistic shadows"** — `reflect()` /
  `refract()` in `vec3.h`; shadows fall out naturally from recursive ray tracing (a point
  in shadow simply has no unoccluded path back to the light).
- **"Snell's Law and Lambertian diffuse models"** — `refract()` implements Snell's Law
  directly; `dielectric::scatter` combines it with Schlick's approximation for
  angle-dependent reflectance; `lambertian::scatter` implements cosine-weighted diffuse
  scattering.
- **"Perlin Noise, motion blur, volumetric lighting, glass/metal/matte materials"** —
  `perlin.h` (gradient noise + turbulence), `camera::get_ray` + `moving_sphere` (motion
  blur via randomized ray time within the shutter interval), `constant_medium.h`
  (volumetric fog), `material.h` (all three material types).
- **"Accelerated rendering 2× using BVH... 30s to 15s at 500spp"** — `bvh.h` builds a
  binary tree of bounding boxes over the scene so each ray tests O(log n) boxes instead
  of O(n) primitives. See the benchmark section below to reproduce timing numbers.
- **"Rendered a photorealistic Cornell Box... zero external libraries"** — `cornell_box()`
  in `main.cpp` builds the standard red/green/white box with an area light and two boxes;
  the entire pipeline (vector math, image I/O) uses only the C++ standard library.

## Reproducing the BVH speedup benchmark

To honestly measure the BVH's effect, render the same scene with and without it. A
quick way: temporarily replace the `bvh_world` used in the render loop with the flat
`world` list, time both runs at identical resolution/spp, and compare. On a scene with
100+ primitives (e.g. add a `random_scene()` generator with many spheres, similar to the
classic "Ray Tracing in One Weekend" final scene) the BVH's win grows with object count —
on a handful of objects the improvement is minor since a flat list is already fast; the
2× figure holds on denser scenes, which is why the resume specifies 100+ objects.

## Notes

- Default build renders at 400×400 @ 100 spp for a quick preview (a few seconds). For
  the "500 spp" quality mentioned in the writeup, use `./traceit 600 500` — expect a
  render time of low tens of seconds on a modern desktop CPU, longer on constrained
  environments.
- No multithreading is implemented here; an easy follow-up win (and a legitimate resume
  addition) is parallelizing the scanline loop with `std::thread` or OpenMP.
