#pragma once
#include "rtweekend.h"
#include "perlin.h"

class texture {
public:
    virtual ~texture() = default;
    virtual color value(double u, double v, const point3& p) const = 0;
};

class solid_color : public texture {
public:
    solid_color(color c) : color_value(c) {}
    solid_color(double red, double green, double blue) : solid_color(color(red,green,blue)) {}

    color value(double u, double v, const point3& p) const override {
        return color_value;
    }

private:
    color color_value;
};

class checker_texture : public texture {
public:
    checker_texture(shared_ptr<texture> even, shared_ptr<texture> odd) : even(even), odd(odd) {}
    checker_texture(color c1, color c2)
        : even(make_shared<solid_color>(c1)), odd(make_shared<solid_color>(c2)) {}

    color value(double u, double v, const point3& p) const override {
        double sines = std::sin(10*p.x())*std::sin(10*p.y())*std::sin(10*p.z());
        return sines < 0 ? odd->value(u,v,p) : even->value(u,v,p);
    }

private:
    shared_ptr<texture> even, odd;
};

// Marble-like Perlin noise texture (used for procedural, non-uniform surfaces).
class noise_texture : public texture {
public:
    noise_texture() : scale(1) {}
    noise_texture(double sc) : scale(sc) {}

    color value(double u, double v, const point3& p) const override {
        return color(1,1,1) * 0.5 * (1 + std::sin(scale*p.z() + 10*noise.turb(p)));
    }

private:
    perlin noise;
    double scale;
};
