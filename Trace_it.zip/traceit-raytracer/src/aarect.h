#pragma once
#include "rtweekend.h"
#include "hittable.h"
#include "hittable_list.h"

class xy_rect : public hittable {
public:
    xy_rect() {}
    xy_rect(double _x0, double _x1, double _y0, double _y1, double _k, shared_ptr<material> mat)
        : x0(_x0), x1(_x1), y0(_y0), y1(_y1), k(_k), mp(mat) {}

    bool hit(const ray& r, double t_min, double t_max, hit_record& rec) const override {
        double t = (k-r.origin().z()) / r.direction().z();
        if (t < t_min || t > t_max) return false;
        double x = r.origin().x() + t*r.direction().x();
        double y = r.origin().y() + t*r.direction().y();
        if (x < x0 || x > x1 || y < y0 || y > y1) return false;
        rec.u = (x-x0)/(x1-x0);
        rec.v = (y-y0)/(y1-y0);
        rec.t = t;
        vec3 outward_normal(0,0,1);
        rec.set_face_normal(r, outward_normal);
        rec.mat_ptr = mp;
        rec.p = r.at(t);
        return true;
    }

    bool bounding_box(double time0, double time1, aabb& output_box) const override {
        output_box = aabb(point3(x0,y0,k-0.0001), point3(x1,y1,k+0.0001));
        return true;
    }

public:
    shared_ptr<material> mp;
    double x0, x1, y0, y1, k;
};

class xz_rect : public hittable {
public:
    xz_rect() {}
    xz_rect(double _x0, double _x1, double _z0, double _z1, double _k, shared_ptr<material> mat)
        : x0(_x0), x1(_x1), z0(_z0), z1(_z1), k(_k), mp(mat) {}

    bool hit(const ray& r, double t_min, double t_max, hit_record& rec) const override {
        double t = (k-r.origin().y()) / r.direction().y();
        if (t < t_min || t > t_max) return false;
        double x = r.origin().x() + t*r.direction().x();
        double z = r.origin().z() + t*r.direction().z();
        if (x < x0 || x > x1 || z < z0 || z > z1) return false;
        rec.u = (x-x0)/(x1-x0);
        rec.v = (z-z0)/(z1-z0);
        rec.t = t;
        vec3 outward_normal(0,1,0);
        rec.set_face_normal(r, outward_normal);
        rec.mat_ptr = mp;
        rec.p = r.at(t);
        return true;
    }

    bool bounding_box(double time0, double time1, aabb& output_box) const override {
        output_box = aabb(point3(x0,k-0.0001,z0), point3(x1,k+0.0001,z1));
        return true;
    }

public:
    shared_ptr<material> mp;
    double x0, x1, z0, z1, k;
};

class yz_rect : public hittable {
public:
    yz_rect() {}
    yz_rect(double _y0, double _y1, double _z0, double _z1, double _k, shared_ptr<material> mat)
        : y0(_y0), y1(_y1), z0(_z0), z1(_z1), k(_k), mp(mat) {}

    bool hit(const ray& r, double t_min, double t_max, hit_record& rec) const override {
        double t = (k-r.origin().x()) / r.direction().x();
        if (t < t_min || t > t_max) return false;
        double y = r.origin().y() + t*r.direction().y();
        double z = r.origin().z() + t*r.direction().z();
        if (y < y0 || y > y1 || z < z0 || z > z1) return false;
        rec.u = (y-y0)/(y1-y0);
        rec.v = (z-z0)/(z1-z0);
        rec.t = t;
        vec3 outward_normal(1,0,0);
        rec.set_face_normal(r, outward_normal);
        rec.mat_ptr = mp;
        rec.p = r.at(t);
        return true;
    }

    bool bounding_box(double time0, double time1, aabb& output_box) const override {
        output_box = aabb(point3(k-0.0001,y0,z0), point3(k+0.0001,y1,z1));
        return true;
    }

public:
    shared_ptr<material> mp;
    double y0, y1, z0, z1, k;
};

// Axis-aligned box built from six rectangles, used for the two blocks inside the Cornell box.
class box : public hittable {
public:
    box() {}
    box(const point3& p0, const point3& p1, shared_ptr<material> ptr) {
        box_min = p0;
        box_max = p1;

        sides.add(make_shared<xy_rect>(p0.x(), p1.x(), p0.y(), p1.y(), p1.z(), ptr));
        sides.add(make_shared<xy_rect>(p0.x(), p1.x(), p0.y(), p1.y(), p0.z(), ptr));

        sides.add(make_shared<xz_rect>(p0.x(), p1.x(), p0.z(), p1.z(), p1.y(), ptr));
        sides.add(make_shared<xz_rect>(p0.x(), p1.x(), p0.z(), p1.z(), p0.y(), ptr));

        sides.add(make_shared<yz_rect>(p0.y(), p1.y(), p0.z(), p1.z(), p1.x(), ptr));
        sides.add(make_shared<yz_rect>(p0.y(), p1.y(), p0.z(), p1.z(), p0.x(), ptr));
    }

    bool hit(const ray& r, double t_min, double t_max, hit_record& rec) const override {
        return sides.hit(r, t_min, t_max, rec);
    }

    bool bounding_box(double time0, double time1, aabb& output_box) const override {
        output_box = aabb(box_min, box_max);
        return true;
    }

public:
    point3 box_min, box_max;
    hittable_list sides;
};

// Translation and rotation wrappers so boxes can be positioned/rotated within the scene.
class translate : public hittable {
public:
    translate(shared_ptr<hittable> p, const vec3& displacement) : ptr(p), offset(displacement) {}

    bool hit(const ray& r, double t_min, double t_max, hit_record& rec) const override {
        ray moved_r(r.origin() - offset, r.direction(), r.time());
        if (!ptr->hit(moved_r, t_min, t_max, rec)) return false;
        rec.p += offset;
        rec.set_face_normal(moved_r, rec.normal);
        return true;
    }

    bool bounding_box(double time0, double time1, aabb& output_box) const override {
        if (!ptr->bounding_box(time0, time1, output_box)) return false;
        output_box = aabb(output_box.min() + offset, output_box.max() + offset);
        return true;
    }

private:
    shared_ptr<hittable> ptr;
    vec3 offset;
};

class rotate_y : public hittable {
public:
    rotate_y(shared_ptr<hittable> p, double angle) : ptr(p) {
        double radians = degrees_to_radians(angle);
        sin_theta = std::sin(radians);
        cos_theta = std::cos(radians);
        hasbox = ptr->bounding_box(0, 1, bbox);

        point3 min( infinity,  infinity,  infinity);
        point3 max(-infinity, -infinity, -infinity);

        for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++)
        for (int k = 0; k < 2; k++) {
            double x = i*bbox.max().x() + (1-i)*bbox.min().x();
            double y = j*bbox.max().y() + (1-j)*bbox.min().y();
            double z = k*bbox.max().z() + (1-k)*bbox.min().z();

            double newx =  cos_theta*x + sin_theta*z;
            double newz = -sin_theta*x + cos_theta*z;

            vec3 tester(newx, y, newz);
            for (int c = 0; c < 3; c++) {
                min[c] = std::fmin(min[c], tester[c]);
                max[c] = std::fmax(max[c], tester[c]);
            }
        }
        bbox = aabb(min, max);
    }

    bool hit(const ray& r, double t_min, double t_max, hit_record& rec) const override {
        point3 origin = r.origin();
        vec3 direction = r.direction();

        origin[0] = cos_theta*r.origin()[0] - sin_theta*r.origin()[2];
        origin[2] = sin_theta*r.origin()[0] + cos_theta*r.origin()[2];

        direction[0] = cos_theta*r.direction()[0] - sin_theta*r.direction()[2];
        direction[2] = sin_theta*r.direction()[0] + cos_theta*r.direction()[2];

        ray rotated_r(origin, direction, r.time());
        if (!ptr->hit(rotated_r, t_min, t_max, rec)) return false;

        point3 p = rec.p;
        vec3 normal = rec.normal;

        p[0] =  cos_theta*rec.p[0] + sin_theta*rec.p[2];
        p[2] = -sin_theta*rec.p[0] + cos_theta*rec.p[2];

        normal[0] =  cos_theta*rec.normal[0] + sin_theta*rec.normal[2];
        normal[2] = -sin_theta*rec.normal[0] + cos_theta*rec.normal[2];

        rec.p = p;
        rec.set_face_normal(rotated_r, normal);
        return true;
    }

    bool bounding_box(double time0, double time1, aabb& output_box) const override {
        output_box = bbox;
        return hasbox;
    }

private:
    shared_ptr<hittable> ptr;
    double sin_theta, cos_theta;
    bool hasbox;
    aabb bbox;
};
