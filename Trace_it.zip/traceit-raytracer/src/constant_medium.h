#pragma once
#include "rtweekend.h"
#include "hittable.h"
#include "material.h"
#include "texture.h"

// Isotropic scattering: light scatters uniformly in a random direction, used inside fog/smoke.
class isotropic : public material {
public:
    isotropic(color c) : albedo(make_shared<solid_color>(c)) {}
    isotropic(shared_ptr<texture> a) : albedo(a) {}

    bool scatter(const ray& r_in, const hit_record& rec, color& attenuation, ray& scattered)
    const override {
        scattered = ray(rec.p, random_in_unit_sphere(), r_in.time());
        attenuation = albedo->value(rec.u, rec.v, rec.p);
        return true;
    }

private:
    shared_ptr<texture> albedo;
};

// A constant-density participating medium (fog/smoke). A ray passing through has a
// probability of scattering at any point proportional to the density, producing
// volumetric lighting / god-ray style effects (e.g. hazy light shafts in the Cornell box).
class constant_medium : public hittable {
public:
    constant_medium(shared_ptr<hittable> b, double d, shared_ptr<texture> a)
        : boundary(b), neg_inv_density(-1/d),
          phase_function(make_shared<isotropic>(a)) {}

    constant_medium(shared_ptr<hittable> b, double d, color c)
        : boundary(b), neg_inv_density(-1/d),
          phase_function(make_shared<isotropic>(c)) {}

    bool hit(const ray& r, double t_min, double t_max, hit_record& rec) const override {
        const bool enableDebug = false;

        hit_record rec1, rec2;

        if (!boundary->hit(r, -infinity, infinity, rec1)) return false;
        if (!boundary->hit(r, rec1.t+0.0001, infinity, rec2)) return false;

        if (rec1.t < t_min) rec1.t = t_min;
        if (rec2.t > t_max) rec2.t = t_max;
        if (rec1.t >= rec2.t) return false;
        if (rec1.t < 0) rec1.t = 0;

        double ray_length = r.direction().length();
        double distance_inside_boundary = (rec2.t - rec1.t) * ray_length;
        double hit_distance = neg_inv_density * std::log(random_double());

        if (hit_distance > distance_inside_boundary) return false;

        rec.t = rec1.t + hit_distance / ray_length;
        rec.p = r.at(rec.t);

        rec.normal = vec3(1,0,0); // arbitrary
        rec.front_face = true;
        rec.mat_ptr = phase_function;

        return true;
    }

    bool bounding_box(double time0, double time1, aabb& output_box) const override {
        return boundary->bounding_box(time0, time1, output_box);
    }

private:
    shared_ptr<hittable> boundary;
    double neg_inv_density;
    shared_ptr<material> phase_function;
};

