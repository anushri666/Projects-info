#ifndef SHAPE_H
#define SHAPE_H

#include <string>
using namespace std;

class Shape {
protected:
    string color;
    int id;

public:
    Shape(const string& color , int id);
    virtual ~Shape() = default;

    // Pure virtual functions
    virtual double area() const = 0;
    virtual double perimeter () const = 0;
    virtual string getType () const = 0;
    virtual void display () const = 0;

    // Common methods
    string getColor () const;
    void setColor(const string& color);
    int getId() const;
};

#endif
