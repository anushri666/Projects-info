#include "Shape.h"

Shape::Shape(const string& color, int id) : color(color), id(id) {}

string Shape::getColor() const {
    return color;
}

void Shape::setColor(const string& color) {
    this->color = color;
}

int Shape::getId() const {
    return id;
}
