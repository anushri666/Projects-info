#ifndef POLYGON_H
#define POLYGON_H

#include "Shape.h"
#include <vector>
#include <iostream>

class Polygon : public Shape {
private:
    std::vector<double> sides;

public:
    Polygon(const string& color, int id, const vector<double>& sides);
    ~Polygon() override {}

    double area() const override;
    double perimeter() const override;
    string getType() const override;
    void display() const override;

    Polygon& operator*=(double factor);
    bool operator==(const Polygon& other) const;
    friend ostream& operator<<(ostream& os, const Polygon& poly);
};

#endif
