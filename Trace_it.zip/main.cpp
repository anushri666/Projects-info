#include <iostream>
#include "Circle.h"
using namespace std;

int main() {
    Circle c("Red", 1, 5.0);
    c.display();

    c += 2.0;
    cout << "After scaling: " << c << endl;

    return 0;
}
