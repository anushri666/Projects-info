#include "Polygon.h"
#include <stdexcept>

Polygon::Polygon(const string& color, int id, const vector<double>& sides)
    : Shape(color, id), sides(sides) {
    if (sides.size() < 3)
        throw invalid_argument("A polygon must have at least 3 sides.");
}

double Polygon::area() const {
    // Stub: Implement actual polygon area computation if needed
    return 0;
}

double Polygon::perimeter() const {
    double p = 0;
    for (double side : sides)
        p += side;
    return p;
}

string Polygon::getType() const {
    return "Polygon";
}

void Polygon::display() const {
    cout << "Shape ID: " << id << ", Type: " << getType()
         << ", Color: " << color << ", Sides: " << sides.size()
         << ", Perimeter: " << perimeter() << endl;
}

Polygon& Polygon::operator*=(double factor) {
    for (double& side : sides)
        side *= factor;
    return *this;
}

bool Polygon::operator==(const Polygon& other) const {
    return sides == other.sides;
}

ostream& operator<<(ostream& os, const Polygon& poly) {
    os << "Polygon(ID=" << poly.id << ", Sides=" << poly.sides.size() << ")";
    return os;
}
