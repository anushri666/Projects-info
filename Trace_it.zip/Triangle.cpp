#include "Triangle.h"
#include <cmath>
#include <stdexcept>

Triangle::Triangle(const string& color, int id, double a, double b, double c)
    : Shape(color, id), a(a), b(b), c(c) {
    if (a + b <= c || a + c <= b || b + c <= a)
        throw invalid_argument("Invalid triangle side lengths");
}

double Triangle::area() const {
    double s = perimeter() / 2;
    return sqrt(s * (s - a) * (s - b) * (s - c));
}

double Triangle::perimeter() const {
    return a + b + c;
}

string Triangle::getType() const {
    return "Triangle";
}

void Triangle::display() const {
    cout << "Shape ID: " << id << ", Type: " << getType()
         << ", Color: " << color << ", Sides: (" << a << ", " << b << ", " << c << ")"
         << ", Area: " << area() << ", Perimeter: " << perimeter() << endl;
}

Triangle& Triangle::operator+=(double d) {
    a += d; b += d; c += d;
    return *this;
}

bool Triangle::operator==(const Triangle& other) const {
    return a == other.a && b == other.b && c == other.c;
}

ostream& operator<<(ostream& os, const Triangle& t) {
    os << "Triangle(ID=" << t.id << ", a=" << t.a << ", b=" << t.b << ", c=" << t.c << ")";
    return os;
}
