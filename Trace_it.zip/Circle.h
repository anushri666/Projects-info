#ifndef CIRCLE_H
#define CIRCLE_H

#include "Shape.h"
#include <iostream>

class Circle : public Shape {
private:
    double radius;

public:
    Circle(const string& color , int id , double radius);
    ~Circle () override {}

    // Override virtual functions
    double area() const override;
    double perimeter () const override;
    string getType () const override;
    void display () const override;

    // Circle-specific methods
    double getRadius () const;
    void setRadius(double radius);
    double getDiameter () const;

    // Operator overloads
    Circle& operator +=( double scalar);
    bool operator ==( const Circle& other) const;
    friend ostream& operator <<(ostream& os , const Circle& circle);
};

#endif
